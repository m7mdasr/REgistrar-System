public class User {
	
	String user_Name;
	String id;
	String password;
	
	public User(String user_Name,String id,String password) {
		this.user_Name = user_Name;
		this.id = id;
		this.password = password;
	}
	
	//this method return true if the given id and password are correct
	public boolean login(String id , String password) {
		if(id.equals(this.id) && password.equals(this.password))
			return true;
		else return false;
	}
	
	//this method compare the given password with the real password
	public boolean comparePassword(String password) {
		if(password.equals(this.password))
			return true;
		else return false;
	}
	
	//this method change the given password with the real password
	public void setPassword(String password) {
			this.password = password;
	}
	
}