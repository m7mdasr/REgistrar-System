import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.ImageIcon;

public class Login extends JFrame implements ActionListener{

	JTextField id_TextField;
	JTextField password_TextField;
	JButton Login_Button;
	JLabel id_Label;
	JLabel pass_Label;
	JLabel incorrect_password;
	JPanel panel;
	
	
	Login() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		//Here the user should write the ID
		id_TextField = new JTextField();
		id_TextField.setBounds(162, 101, 144, 20);
		getContentPane().add(id_TextField);
		id_TextField.setColumns(10);
		
		id_Label = new JLabel("ID");
		id_Label.setBounds(90, 104, 46, 14);
		getContentPane().add(id_Label);
		
		//Here the user should write the Password
		password_TextField = new JTextField();
		password_TextField.setColumns(10);
		password_TextField.setBounds(162, 132, 144, 20);
		getContentPane().add(password_TextField);
		
		pass_Label = new JLabel("Password");
		pass_Label.setBounds(90, 135, 62, 14);
		getContentPane().add(pass_Label);
		
		//This button for login
		Login_Button = new JButton("Login");
		Login_Button.addActionListener(this);
		Login_Button.setBounds(188, 174, 89, 23);
		getContentPane().add(Login_Button);
		
		incorrect_password = new JLabel("");
		incorrect_password.setFont(new Font("Tahoma", Font.BOLD, 11));
		incorrect_password.setForeground(new Color(255, 0, 0));
		incorrect_password.setBounds(162, 81, 144, 14);
		getContentPane().add(incorrect_password);
				
	}
		
	public void actionPerformed(ActionEvent e) {
		
		String id = id_TextField.getText();
		String Password = password_TextField.getText();
		
		boolean login = Student.St1.login(id, Password);
		
		
		if(!login) incorrect_password.setText("Incorrect ID or Password");
		else {
			Registration d= new Registration();
			d.setVisible(true);
				setVisible(false);
			}
	}
	
	public static void main(String[]args) {
		new Login().setVisible(true);
	}
}