import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ChangePassword extends JFrame implements ActionListener{

	JTextField current_Password;
	JTextField new_Password;
	JTextField new_Password_Again;
	JButton confirm_Button;
	JLabel current_Password_Label;
	JLabel new_Password_Label;
	JLabel new_Password_Again_Label;
	JLabel incorrect_Password_Label;
	
		
	ChangePassword() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		//Where the current Password should be confirmed
		current_Password = new JTextField();
		current_Password.setColumns(10);
		current_Password.setBounds(162, 69, 144, 20);
		getContentPane().add(current_Password);
		
		current_Password_Label = new JLabel("Current");
		current_Password_Label.setBounds(90, 71, 62, 14);
		getContentPane().add(current_Password_Label);
		
		
		//Where the new Password should be given
		new_Password = new JTextField();
		new_Password.setBounds(162, 101, 144, 20);
		getContentPane().add(new_Password);
		new_Password.setColumns(10);
		
		new_Password_Label = new JLabel("New");
		new_Password_Label.setBounds(90, 104, 46, 14);
		getContentPane().add(new_Password_Label);
		
		
		//Where the new Password should be confirmed
		new_Password_Again = new JTextField();
		new_Password_Again.setColumns(10);
		new_Password_Again.setBounds(162, 132, 144, 20);
		getContentPane().add(new_Password_Again);
		
		new_Password_Again_Label = new JLabel("Retype New Password");
		new_Password_Again_Label.setBounds(90, 135, 73, 14);
		getContentPane().add(new_Password_Again_Label);
		
		
		//This button confirm the new Password
		confirm_Button = new JButton("Confirm");
		confirm_Button.addActionListener(this);
		confirm_Button.setBounds(188, 174, 89, 23);
		getContentPane().add(confirm_Button);
		
		//This label will be modified if the current password was wrong or the new password doesn't match the confirmed one
		incorrect_Password_Label = new JLabel("");
		incorrect_Password_Label.setFont(new Font("Tahoma", Font.BOLD, 11));
		incorrect_Password_Label.setForeground(new Color(255, 0, 0));
		incorrect_Password_Label.setBounds(162, 26, 144, 14);
		getContentPane().add(incorrect_Password_Label);
		
	}
		
	public void actionPerformed(ActionEvent e) {
		
		String Password = current_Password.getText();
		boolean login = Student.St1.comparePassword(Password);
		String Pass2 = new_Password.getText();
		String Pass3 = new_Password_Again.getText();
		
		if(!login || !(Pass2.equals(Pass3)) ) 
			incorrect_Password_Label.setText("Incorrect Password");
		else {
			Student.St1.setPassword(Pass2);
			setVisible(false);
			}
	}
	
	public static void main(String[]args) {
		new ChangePassword().setVisible(true);
	}
}