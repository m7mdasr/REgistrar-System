
public class Section extends Course{
	
	
	String lecturer;
	String location;
	int section_number;
	String timing;
	String type;
	
	static Section sec1 = new Section("MATH201","Mathematics",3,83647,"Khaled Ali","Building 6 / Room 125",1,"8:00 To 8:50","Lec");
	static Section sec2 = new Section("MATH201","Mathematics",3,83648,"Waled Adam","Building 4 / Room 110",2,"8:00 To 8:50","Lec");
	static Section sec3 = new Section("MATH201","Mathematics",3,83649,"Omar Alsoma","Building 7 / Room 120",3,"9:00 To 9:50","Lec");
	static Section sec4 = new Section("MATH201","Mathematics",3,83650,"Rashed Majed","Building 4 / Room 136",4,"10:00 To 10:50","Lec");
	static Section sec5 = new Section("MATH201","Mathematics",3,83651,"Mohammed Salah","Building 6 / Room 125",5,"11:00 To 11:50","Lec");
	static Section sec6 = new Section("MATH201","Mathematics",3,83652,"Ahmed Mekky","Building 6 / Room 121",6,"10:30 To 11:75","Lec");
	
	public Section(String course_Name, String course_Department, int course_credit, int CRN, String lecturer, String location, int section_number, String timing, String type) {
		super(course_Name, course_Department, course_credit, CRN);

		this.lecturer = lecturer;
		this.location = location;
		this.section_number = section_number;
		this.timing = timing;
		this.type = type;
	}
	
	public String toString() {
		String s = course_Name+"/"+timing+"/"+lecturer+"/"+location+"/"+course_credit+"/"+CRN+"/"+type;
		return s;
	}
	
}