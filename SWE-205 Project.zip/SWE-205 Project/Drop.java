import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JSeparator;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JList;

public class Drop extends JFrame{

	
	JRadioButton[] rdbtnDrop = new JRadioButton[6];
	JMenu menu;
	JMenuBar menu_Bar;
	JMenuItem Item1;
	JMenuItem Item2;
	JMenuItem Item3;
	JMenuItem Item4;
	JButton return_Button;
	JButton submit_Button;
	
	public Drop() {

		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 1037, 431);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		setResizable(false);
		
		
		//The menu that contains the setting options
		menu = new JMenu("Personal Information ");
		menu_Bar = new JMenuBar();
		menu_Bar.setBounds(803, 0, 230, 25);
		getContentPane().add(menu_Bar);
		menu_Bar.add(menu);
		
		//Change password Option
		Item1 = new JMenuItem("Change Password");
		Item1.setBounds(497, 24, 183, 19);
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChangePassword().main(null);
			}
		});
		menu.add(Item1);
		
		//View Address and Phone number Option
		Item2 = new JMenuItem("View Address and Phone");
		Item2.setBounds(479, 45, 199, 19);
		menu.add(Item2);
		
		//Update Address and Phone number Option
		Item3 = new JMenuItem("Update Address and Phone");
		Item3.setBounds(479, 68, 195, 19);
		menu.add(Item3);
		
		//This button returns the user back to the previous page 
		return_Button = new JButton("Back");
		return_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Registration().setVisible(true);
				setVisible(false);
			}
		});
		return_Button.setBounds(0, 0, 117, 29);
		getContentPane().add(return_Button);
		
		//This panel contains the columns headers
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(new Color(0, 128, 0));
		panel.setBounds(0, 113, 1033, 42);
		getContentPane().add(panel);
		panel.setLayout(new GridLayout(0, 9, 0, 0));
		
		//Drop course column header
		JLabel lblAdd = new JLabel("Drop");
		lblAdd.setForeground(new Color(255, 255, 255));
		lblAdd.setBackground(Color.GRAY);
		lblAdd.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblAdd);
		
		//Course timing column header
		JLabel lblTiming = new JLabel("Time");
		lblTiming.setForeground(new Color(255, 255, 255));
		lblTiming.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblTiming);
		
		//Course days column header
		JLabel lblDays = new JLabel("Days");
		lblDays.setForeground(new Color(255, 255, 255));
		lblDays.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblDays);
		
		//Course location column header
		JLabel lblLocation = new JLabel("Location");
		lblLocation.setForeground(new Color(255, 255, 255));
		lblLocation.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblLocation);
		
		//Course credit column header
		JLabel lblCredit = new JLabel("Credit");
		lblCredit.setForeground(new Color(255, 255, 255));
		lblCredit.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCredit);
		
		//Course CRN column header
		JLabel lblCourseCrn = new JLabel("Course CRN");
		lblCourseCrn.setForeground(new Color(255, 255, 255));
		lblCourseCrn.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCourseCrn);
		
		//Course type column header
		JLabel lblType = new JLabel("Type");
		lblType.setForeground(new Color(255, 255, 255));
		lblType.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblType);
		
		//Course instructor column header
		JLabel lblInstroctur = new JLabel("Instructor");
		lblInstroctur.setForeground(new Color(255, 255, 255));
		lblInstroctur.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblInstroctur);
		
		//Course name column header
		JLabel lblCourse = new JLabel("Course");
		lblCourse.setForeground(new Color(255, 255, 255));
		lblCourse.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCourse);
		
		//This panel contains the raws that contain the information of each section according to the column header  
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(0, 154, 1033, 285);
		getContentPane().add(panel_1);
		
		//Section 1
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(Color.WHITE);
		panel_2.setBackground(Color.GRAY);
		panel_2.setBounds(0, 0, 1033, 42);
		panel_1.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 9, 0, 2));
		
		rdbtnDrop[0] = new JRadioButton("Drop Section");
		panel_2.add(rdbtnDrop[0]);
		
		JLabel label = new JLabel("8:00 To 8:50");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		panel_2.add(label);
		
		JLabel label_1 = new JLabel("UTR");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(Color.WHITE);
		panel_2.add(label_1);
		
		JLabel label_2 = new JLabel("Building6 /Room125");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setForeground(Color.WHITE);
		panel_2.add(label_2);
		
		JLabel label_3 = new JLabel("3");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(Color.WHITE);
		panel_2.add(label_3);
		
		JLabel label_4 = new JLabel("83647");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setForeground(Color.WHITE);
		panel_2.add(label_4);
		
		JLabel label_5 = new JLabel("Lec");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setForeground(Color.WHITE);
		panel_2.add(label_5);
		
		JLabel label_6 = new JLabel("Khaled Ali");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(Color.WHITE);
		panel_2.add(label_6);
		
		JLabel label_7 = new JLabel("Math201");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setForeground(Color.WHITE);
		panel_2.add(label_7);
		
		//Section 2
		JPanel panel_3 = new JPanel();
		panel_3.setForeground(Color.WHITE);
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setBounds(0, 40, 1033, 42);
		panel_1.add(panel_3);
		panel_3.setLayout(new GridLayout(0, 9, 0, 0));
		
		rdbtnDrop[1] = new JRadioButton("Drop Section");
		panel_3.add(rdbtnDrop[1]);
		
		JLabel label_8 = new JLabel("8:00 To 8:50");
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.WHITE);
		panel_3.add(label_8);
		
		JLabel label_9 = new JLabel("UTR");
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(Color.WHITE);
		panel_3.add(label_9);
		
		JLabel lblBuildingRoom_3 = new JLabel("Building4 /Room110");
		lblBuildingRoom_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_3.setForeground(Color.WHITE);
		panel_3.add(lblBuildingRoom_3);
		
		JLabel label_11 = new JLabel("3");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setForeground(Color.WHITE);
		panel_3.add(label_11);
		
		JLabel label_12 = new JLabel("83648");
		label_12.setHorizontalAlignment(SwingConstants.CENTER);
		label_12.setForeground(Color.WHITE);
		panel_3.add(label_12);
		
		JLabel label_13 = new JLabel("Lec");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setForeground(Color.WHITE);
		panel_3.add(label_13);
		
		JLabel label_14 = new JLabel("Waleed Adam");
		label_14.setHorizontalAlignment(SwingConstants.CENTER);
		label_14.setForeground(Color.WHITE);
		panel_3.add(label_14);
		
		JLabel label_15 = new JLabel("Math201");
		label_15.setHorizontalAlignment(SwingConstants.CENTER);
		label_15.setForeground(Color.WHITE);
		panel_3.add(label_15);
		
		//Section 3
		JPanel panel_4 = new JPanel();
		panel_4.setForeground(Color.WHITE);
		panel_4.setBackground(Color.GRAY);
		panel_4.setBounds(0, 82, 1033, 42);
		panel_1.add(panel_4);
		panel_4.setLayout(new GridLayout(0, 9, 0, 0));
		
		rdbtnDrop[2] = new JRadioButton("Drop Section");
		panel_4.add(rdbtnDrop[2]);
		
		JLabel label_16 = new JLabel("9:00 To 9:50");
		label_16.setHorizontalAlignment(SwingConstants.CENTER);
		label_16.setForeground(Color.WHITE);
		panel_4.add(label_16);
		
		JLabel label_17 = new JLabel("UTR");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setForeground(Color.WHITE);
		panel_4.add(label_17);
		
		JLabel lblBuildingRoom_2 = new JLabel("Building7 /Room120");
		lblBuildingRoom_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_2.setForeground(Color.WHITE);
		panel_4.add(lblBuildingRoom_2);
		
		JLabel label_19 = new JLabel("3");
		label_19.setHorizontalAlignment(SwingConstants.CENTER);
		label_19.setForeground(Color.WHITE);
		panel_4.add(label_19);
		
		JLabel label_20 = new JLabel("83649");
		label_20.setHorizontalAlignment(SwingConstants.CENTER);
		label_20.setForeground(Color.WHITE);
		panel_4.add(label_20);
		
		JLabel label_21 = new JLabel("Lec");
		label_21.setHorizontalAlignment(SwingConstants.CENTER);
		label_21.setForeground(Color.WHITE);
		panel_4.add(label_21);
		
		JLabel label_22 = new JLabel("Omar Alsoma");
		label_22.setHorizontalAlignment(SwingConstants.CENTER);
		label_22.setForeground(Color.WHITE);
		panel_4.add(label_22);
		
		JLabel label_23 = new JLabel("Math201");
		label_23.setHorizontalAlignment(SwingConstants.CENTER);
		label_23.setForeground(Color.WHITE);
		panel_4.add(label_23);
		
		//Section 4
		JPanel panel_5 = new JPanel();
		panel_5.setForeground(Color.WHITE);
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(0, 123, 1033, 42);
		panel_1.add(panel_5);
		panel_5.setLayout(new GridLayout(0, 9, 0, 0));
		
		rdbtnDrop[3] = new JRadioButton("Drop Section");
		panel_5.add(rdbtnDrop[3]);
		
		JLabel lblTo_1 = new JLabel("10:00 To 10:50");
		lblTo_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo_1.setForeground(Color.WHITE);
		panel_5.add(lblTo_1);
		
		JLabel label_25 = new JLabel("UTR");
		label_25.setHorizontalAlignment(SwingConstants.CENTER);
		label_25.setForeground(Color.WHITE);
		panel_5.add(label_25);
		
		JLabel lblBuildingRoom_1 = new JLabel("Building4 /Room136");
		lblBuildingRoom_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_1.setForeground(Color.WHITE);
		panel_5.add(lblBuildingRoom_1);
		
		JLabel label_27 = new JLabel("3");
		label_27.setHorizontalAlignment(SwingConstants.CENTER);
		label_27.setForeground(Color.WHITE);
		panel_5.add(label_27);
		
		JLabel label_28 = new JLabel("83650");
		label_28.setHorizontalAlignment(SwingConstants.CENTER);
		label_28.setForeground(Color.WHITE);
		panel_5.add(label_28);
		
		JLabel label_29 = new JLabel("Lec");
		label_29.setHorizontalAlignment(SwingConstants.CENTER);
		label_29.setForeground(Color.WHITE);
		panel_5.add(label_29);
		
		JLabel lblRashemMajed = new JLabel("Rashem Majed");
		lblRashemMajed.setHorizontalAlignment(SwingConstants.CENTER);
		lblRashemMajed.setForeground(Color.WHITE);
		panel_5.add(lblRashemMajed);
		
		JLabel label_31 = new JLabel("Math201");
		label_31.setHorizontalAlignment(SwingConstants.CENTER);
		label_31.setForeground(Color.WHITE);
		panel_5.add(label_31);
		
		//Section 5
		JPanel panel_6 = new JPanel();
		panel_6.setForeground(Color.WHITE);
		panel_6.setBackground(Color.GRAY);
		panel_6.setBounds(0, 164, 1033, 42);
		panel_1.add(panel_6);
		panel_6.setLayout(new GridLayout(0, 9, 0, 0));
		
		rdbtnDrop[4] = new JRadioButton("Drop Section");
		panel_6.add(rdbtnDrop[4]);
		
		JLabel lblTo = new JLabel("11:00 To 11:50");
		lblTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo.setForeground(Color.WHITE);
		panel_6.add(lblTo);
		
		JLabel label_33 = new JLabel("UTR");
		label_33.setHorizontalAlignment(SwingConstants.CENTER);
		label_33.setForeground(Color.WHITE);
		panel_6.add(label_33);
		
		JLabel lblBuildingRoom = new JLabel("Building6 /Room125");
		lblBuildingRoom.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom.setForeground(Color.WHITE);
		panel_6.add(lblBuildingRoom);
		
		JLabel label_35 = new JLabel("3");
		label_35.setHorizontalAlignment(SwingConstants.CENTER);
		label_35.setForeground(Color.WHITE);
		panel_6.add(label_35);
		
		JLabel label_36 = new JLabel("83651");
		label_36.setHorizontalAlignment(SwingConstants.CENTER);
		label_36.setForeground(Color.WHITE);
		panel_6.add(label_36);
		
		JLabel label_37 = new JLabel("Lec");
		label_37.setHorizontalAlignment(SwingConstants.CENTER);
		label_37.setForeground(Color.WHITE);
		panel_6.add(label_37);
		
		JLabel lblMohammedSaleh = new JLabel("Mohammed Saleh");
		lblMohammedSaleh.setHorizontalAlignment(SwingConstants.CENTER);
		lblMohammedSaleh.setForeground(Color.WHITE);
		panel_6.add(lblMohammedSaleh);
		
		JLabel label_39 = new JLabel("Math201");
		label_39.setHorizontalAlignment(SwingConstants.CENTER);
		label_39.setForeground(Color.WHITE);
		panel_6.add(label_39);
		
		//Section 6
		JPanel panel_7 = new JPanel();
		panel_7.setForeground(Color.WHITE);
		panel_7.setBackground(Color.LIGHT_GRAY);
		panel_7.setBounds(0, 205, 1033, 42);
		panel_1.add(panel_7);
		panel_7.setLayout(new GridLayout(0, 9, 0, 0));
		
		rdbtnDrop[5] = new JRadioButton("Drop Section");
		panel_7.add(rdbtnDrop[5]);
		
		JLabel lblTo_2 = new JLabel("10:30 To 11:45");
		lblTo_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo_2.setForeground(Color.WHITE);
		panel_7.add(lblTo_2);
		
		JLabel label_41 = new JLabel("MW");
		label_41.setHorizontalAlignment(SwingConstants.CENTER);
		label_41.setForeground(Color.WHITE);
		panel_7.add(label_41);
		
		JLabel lblBuildingRoom_4 = new JLabel("Building6/ Room121");
		lblBuildingRoom_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_4.setForeground(Color.WHITE);
		panel_7.add(lblBuildingRoom_4);
		
		JLabel label_43 = new JLabel("3");
		label_43.setHorizontalAlignment(SwingConstants.CENTER);
		label_43.setForeground(Color.WHITE);
		panel_7.add(label_43);
		
		JLabel label_44 = new JLabel("83652");
		label_44.setHorizontalAlignment(SwingConstants.CENTER);
		label_44.setForeground(Color.WHITE);
		panel_7.add(label_44);
		
		JLabel label_45 = new JLabel("Lec");
		label_45.setHorizontalAlignment(SwingConstants.CENTER);
		label_45.setForeground(Color.WHITE);
		panel_7.add(label_45);
		
		JLabel lblAhmedMekki = new JLabel("Ahmed Mekki");
		lblAhmedMekki.setHorizontalAlignment(SwingConstants.CENTER);
		lblAhmedMekki.setForeground(Color.WHITE);
		panel_7.add(lblAhmedMekki);
		
		JLabel label_47 = new JLabel("Math201");
		label_47.setHorizontalAlignment(SwingConstants.CENTER);
		label_47.setForeground(Color.WHITE);
		panel_7.add(label_47);
		
		//This button add the chosen sections to the ArrayList of sections that each student has
		submit_Button = new JButton("Submit Changes");
		submit_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
					for(int i = 0 ; i<rdbtnDrop.length ; i++) {
						if(rdbtnDrop[i].isSelected()) {
						if(i == 0)Student.St1.drop_Course(Section.sec1);
						else if(i == 1)Student.St1.drop_Course(Section.sec2);
						else if(i == 2)Student.St1.drop_Course(Section.sec3);
						else if(i == 3)Student.St1.drop_Course(Section.sec4);
						else if(i == 4)Student.St1.drop_Course(Section.sec5);
						else if(i == 5)Student.St1.drop_Course(Section.sec6);
						}
					}
					Student.St1.reveal_Courses();
				
			}
		});
		submit_Button.setBounds(858, 78, 175, 37);
		getContentPane().add(submit_Button);
	
	}

}
