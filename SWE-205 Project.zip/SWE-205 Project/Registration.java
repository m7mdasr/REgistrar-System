import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Registration extends JFrame{

	JMenu menu;
	JMenuBar menu_Bar;
	JMenuItem Item1;
	JMenuItem Item2;
	JMenuItem Item3;
	JMenuItem Item4;
	
	public Registration() {
		
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 680, 406);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		setResizable(false);
		
		//The menu that contains the setting options
		menu = new JMenu("Personal Information ");
		menu_Bar = new JMenuBar();
		menu_Bar.setBounds(500, 0, 230, 25);
		getContentPane().add(menu_Bar);
		menu_Bar.add(menu);
		
		//Change password Option
		Item1 = new JMenuItem("Change Password");
		Item1.setBounds(497, 24, 183, 19);
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChangePassword().setVisible(true);
			}
		});
		menu.add(Item1);
		
		//View Address and Phone number Option
		Item2 = new JMenuItem("View Address and Phone");
		Item2.setBounds(479, 45, 199, 19);
		menu.add(Item2);
		
		//Update Address and Phone number Option
		Item3 = new JMenuItem("Update Address and Phone");
		Item3.setBounds(479, 68, 195, 19);
		menu.add(Item3);
		
		//Logout
		Item4 = new JMenuItem("Logout");
		Item4.setBounds(497, 24, 201, 19);
		Item4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Login().setVisible(true);
				setVisible(false);
			}
		});
		menu.add(Item4);
		
		//This panel contains the main menu options
		JPanel panel = new JPanel();
		panel.setBounds(133, 113, 436, 234);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		//This button Open Add courses page
		JButton Add = new JButton("Add Course");
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Student.St1.get_Approval_Status()==false) {
					JOptionPane.showMessageDialog(null, Student.St1.What_Approval_Status());
				}else {
				Add a = new Add();
				a.setVisible(true);
				setVisible(false);
				}
			}
		});
		Add.setBounds(50, 28, 147, 71);
		panel.add(Add);
		
		//This button Open open an option pane that shows the student registration status
		JButton RegSta = new JButton("Registration status");
		RegSta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, Student.St1.What_Approval_Status());
			}
		});
		RegSta.setBounds(50, 111, 147, 71);
		panel.add(RegSta);
		
		//This button Open Drop courses page
		JButton Drop = new JButton("Drop Course");
		Drop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Student.St1.get_Approval_Status()==false) {
					JOptionPane.showMessageDialog(null, Student.St1.What_Approval_Status());
				}else {
				Drop d = new Drop();
				d.setVisible(true);
				setVisible(false);
				}
			}
		});
		Drop.setBounds(247, 28, 147, 71);
		panel.add(Drop);
		
		//This button open the Weekly Schedule (Unavailable)
		JButton WS = new JButton("Weekly Schedule");
		WS.setBounds(247, 111, 147, 71);
		panel.add(WS);
		
	}

	
}
