
import java.util.ArrayList;

public class Student extends User{
	
	boolean approval_Status;
	
	//The courses are added in and dropped from in this ArrayList
	ArrayList<Section> sections = new ArrayList<Section>();
	
	//imaginary user (student)
	static Student St1 = new Student("Khaled","201654321","123",true);
	
	
	public Student(String user_Name, String id, String password, boolean approval_Status) {
		super(user_Name, id, password);
		this.approval_Status = approval_Status;
	}
	
	//this method adds a section
	public void add_Course(Section some_Section) {
		if(approval_Status == true)
			sections.add(some_Section);
	}
	
	//this method drops a section
	public void drop_Course(Section some_Section) {
		if(approval_Status == true)
			sections.remove(some_Section);
	}
	
	//this method reveals the courses that the student has in the Console
	public void reveal_Courses() {
		System.out.println(sections);
	}
	
	//this method returns true if the student is approved, and false if not
	public boolean get_Approval_Status() {
		if(approval_Status == true)
			return true;
		else return false;
	}
	
	//this method returns the student registration status
	public String What_Approval_Status() {
		if(approval_Status == true)
			return "Approved";
		else return "Not Approved";
	}
	
}