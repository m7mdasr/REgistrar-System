import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ChangePassword extends JFrame implements ActionListener{

	private JTextField tF2;
	private JTextField tF3;
	private JButton btnLogin;
	JLabel lblId;
	JLabel lblRetypeNew;
	private JLabel label_1;
	private JPanel panel;
	private JLabel lblNewLabel;
	private final JLabel label_2 = new JLabel("");
	private JTextField tF1;
	
	ChangePassword() {
		
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		tF2 = new JTextField();
		tF2.setBounds(162, 101, 144, 20);
		getContentPane().add(tF2);
		tF2.setColumns(10);
		
		tF3 = new JTextField();
		tF3.setColumns(10);
		tF3.setBounds(162, 132, 144, 20);
		getContentPane().add(tF3);
		
		lblId = new JLabel("New");
		lblId.setBounds(90, 104, 46, 14);
		getContentPane().add(lblId);
		
		lblRetypeNew = new JLabel("Retype New");
		lblRetypeNew.setBounds(90, 135, 73, 14);
		getContentPane().add(lblRetypeNew);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(this);
		btnLogin.setBounds(188, 174, 89, 23);
		getContentPane().add(btnLogin);
		
		label_1 = new JLabel("");
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setForeground(new Color(255, 0, 0));
		label_1.setBounds(162, 26, 144, 14);
		getContentPane().add(label_1);
		label_2.setBounds(355, 0, 89, 95);
		getContentPane().add(label_2);
		label_2.setForeground(Color.RED);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		tF1 = new JTextField();
		tF1.setColumns(10);
		tF1.setBounds(162, 69, 144, 20);
		getContentPane().add(tF1);
		
		JLabel lblCurrentPassword = new JLabel("Current");
		lblCurrentPassword.setBounds(90, 71, 62, 14);
		getContentPane().add(lblCurrentPassword);
		
		
		
	}


	
	public void actionPerformed(ActionEvent e) {
		String Password = tF1.getText();
		boolean login = Student.St1.ChangePassword(Password);
		String Pass2 = tF2.getText();
		String Pass3 = tF3.getText();
		if(!login && Pass2.equals(Pass3) ) 
			label_1.setText("Incorrect Password");
		else {
			Student.St1.setPassword(Password);
			new Main().main(null);
			}
	}
	
	public static void main(String[]args) {
		new ChangePassword().setVisible(true);
	}
}