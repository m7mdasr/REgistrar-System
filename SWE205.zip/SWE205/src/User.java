public class User {
	
	String user_Name;
	String id;
	String password;
	
	public User(String user_Name,String id,String password) {
		this.user_Name = user_Name;
		this.id = id;
		this.password = password;
	}
	
	
	public boolean login(String id , String password) {
		if(id.equals(this.id) && password.equals(this.password))
			return true;
		else return false;
	}
	
	public boolean ChangePassword(String password) {
		if(password.equals(this.password))
			return true;
		else return false;
	}
	
	public void setPassword(String password) {
		if(ChangePassword(password))
			this.password = password;
	}
	
}