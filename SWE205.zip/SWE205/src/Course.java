

public class Course {
	
	String course_Name;
	String course_Departement;
	int course_credit;
	int CRN;
	
	public Course(String course_Name , String course_Department, int course_credit , int CRN) {
		
		this.course_Name = course_Name;
		this.course_Departement = course_Department;
		this.course_credit = course_credit;
		this.CRN = CRN;
		
	}
	
	
}