import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 680, 406);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		
		JButton btn1 = new JButton("Registration");
		Image p1 = new ImageIcon(this.getClass().getResource("/btn1.png")).getImage();
		btn1.setIcon(new ImageIcon(p1));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Registration Rg = new Registration();
				Rg.main(null);
			}
		});
		btn1.setBounds(0, 118, 388, 85);
		btn1.setBackground(Color.GRAY);
		frame.getContentPane().add(btn1);
		
		JButton btn2 = new JButton("New button");
		Image p2 = new ImageIcon(this.getClass().getResource("/btn2.png")).getImage();
		btn2.setIcon(new ImageIcon(p2));
		btn2.setBounds(0, 208, 385, 84);
		btn2.setBackground(Color.GRAY);
		frame.getContentPane().add(btn2);
		
		JButton btn3 = new JButton("New button");
		Image p3 = new ImageIcon(this.getClass().getResource("/btn3.png")).getImage();
		btn3.setIcon(new ImageIcon(p3));
		btn3.setBounds(0, 293, 185, 80);
		frame.getContentPane().add(btn3);
		
		JMenu menu = new JMenu("Personal Information ");
		JMenuBar mBar = new JMenuBar();
		mBar.setBounds(500, 0, 230, 25);
		frame.getContentPane().add(mBar);
		mBar.add(menu);
		
		JMenuItem Item1 = new JMenuItem("Change Password");
		Item1.setBounds(497, 24, 183, 19);
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChangePassword().main(null);
			}
		});
		menu.add(Item1);
		
		JMenuItem Item2 = new JMenuItem("View Address and Phone");
		Item2.setBounds(479, 45, 199, 19);
		menu.add(Item2);
		
		JMenuItem Item3 = new JMenuItem("Update Address and Phone");
		Item3.setBounds(479, 68, 195, 19);
		menu.add(Item3);
		
		JLabel lblNewLabel = new JLabel("");
		Image logo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(logo));
		lblNewLabel.setBounds(6, 28, 408, 73);
		frame.getContentPane().add(lblNewLabel);
	}
}
