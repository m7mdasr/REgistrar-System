import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JSeparator;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JList;

public class Add extends JFrame{

	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add window = new Add();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Add() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 680, 406);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		setResizable(false);
		
		
		
		JMenu menu = new JMenu("Personal Information ");
		JMenuBar mBar = new JMenuBar();
		mBar.setBounds(500, 0, 230, 25);
		getContentPane().add(mBar);
		mBar.add(menu);
		
		JMenuItem Item1 = new JMenuItem("Change Password");
		Item1.setBounds(497, 24, 183, 19);
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChangePassword().main(null);
			}
		});
		menu.add(Item1);
		
		JMenuItem Item2 = new JMenuItem("View Address and Phone");
		Item2.setBounds(479, 45, 199, 19);
		menu.add(Item2);
		
		JMenuItem Item3 = new JMenuItem("Update Address and Phone");
		Item3.setBounds(479, 68, 195, 19);
		menu.add(Item3);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Registration().main(null);
			}
		});
		btnNewButton.setBounds(0, 0, 117, 29);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		Image logo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(logo));
		lblNewLabel.setBounds(6, 28, 408, 73);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(new Color(0, 128, 0));
		panel.setBounds(0, 113, 680, 42);
		getContentPane().add(panel);
		panel.setLayout(new GridLayout(0, 9, 0, 0));
		
		JLabel lblAdd = new JLabel("Add");
		lblAdd.setForeground(new Color(255, 255, 255));
		lblAdd.setBackground(Color.GRAY);
		lblAdd.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblAdd);
		
		JLabel lblTiming = new JLabel("Time");
		lblTiming.setForeground(new Color(255, 255, 255));
		lblTiming.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblTiming);
		
		JLabel lblDays = new JLabel("Days");
		lblDays.setForeground(new Color(255, 255, 255));
		lblDays.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblDays);
		
		JLabel lblLocation = new JLabel("Location");
		lblLocation.setForeground(new Color(255, 255, 255));
		lblLocation.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblLocation);
		
		JLabel lblCredit = new JLabel("Credit");
		lblCredit.setForeground(new Color(255, 255, 255));
		lblCredit.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCredit);
		
		JLabel lblCourseCrn = new JLabel("Course CRN");
		lblCourseCrn.setForeground(new Color(255, 255, 255));
		lblCourseCrn.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCourseCrn);
		
		JLabel lblType = new JLabel("Type");
		lblType.setForeground(new Color(255, 255, 255));
		lblType.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblType);
		
		JLabel lblInstroctur = new JLabel("Instructor");
		lblInstroctur.setForeground(new Color(255, 255, 255));
		lblInstroctur.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblInstroctur);
		
		JLabel lblCourse = new JLabel("Course");
		lblCourse.setForeground(new Color(255, 255, 255));
		lblCourse.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblCourse);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBounds(0, 154, 680, 285);
		getContentPane().add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(Color.WHITE);
		panel_2.setBackground(Color.GRAY);
		panel_2.setBounds(0, 0, 680, 42);
		panel_1.add(panel_2);
		panel_2.setLayout(new GridLayout(0, 9, 0, 2));
		
		JRadioButton radioButton = new JRadioButton("Add Section");
		panel_2.add(radioButton);
		
		JLabel label = new JLabel("8:00 To 8:50");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		panel_2.add(label);
		
		JLabel label_1 = new JLabel("UTR");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setForeground(Color.WHITE);
		panel_2.add(label_1);
		
		JLabel label_2 = new JLabel("Building 6/Room125");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setForeground(Color.WHITE);
		panel_2.add(label_2);
		
		JLabel label_3 = new JLabel("3");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setForeground(Color.WHITE);
		panel_2.add(label_3);
		
		JLabel label_4 = new JLabel("83647");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setForeground(Color.WHITE);
		panel_2.add(label_4);
		
		JLabel label_5 = new JLabel("Lec");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setForeground(Color.WHITE);
		panel_2.add(label_5);
		
		JLabel label_6 = new JLabel("Khaled Ali");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setForeground(Color.WHITE);
		panel_2.add(label_6);
		
		JLabel label_7 = new JLabel("Math201");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setForeground(Color.WHITE);
		panel_2.add(label_7);
		
		JPanel panel_3 = new JPanel();
		panel_3.setForeground(Color.WHITE);
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setBounds(0, 40, 680, 42);
		panel_1.add(panel_3);
		panel_3.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_1 = new JRadioButton("Add Section");
		panel_3.add(radioButton_1);
		
		JLabel label_8 = new JLabel("8:00 To 8:50");
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.WHITE);
		panel_3.add(label_8);
		
		JLabel label_9 = new JLabel("UTR");
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(Color.WHITE);
		panel_3.add(label_9);
		
		JLabel lblBuildingRoom_3 = new JLabel("Building 24 Room 180");
		lblBuildingRoom_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_3.setForeground(Color.WHITE);
		panel_3.add(lblBuildingRoom_3);
		
		JLabel label_11 = new JLabel("3");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setForeground(Color.WHITE);
		panel_3.add(label_11);
		
		JLabel label_12 = new JLabel("83648");
		label_12.setHorizontalAlignment(SwingConstants.CENTER);
		label_12.setForeground(Color.WHITE);
		panel_3.add(label_12);
		
		JLabel label_13 = new JLabel("Lec");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setForeground(Color.WHITE);
		panel_3.add(label_13);
		
		JLabel label_14 = new JLabel("Waleed Adam");
		label_14.setHorizontalAlignment(SwingConstants.CENTER);
		label_14.setForeground(Color.WHITE);
		panel_3.add(label_14);
		
		JLabel label_15 = new JLabel("Math201");
		label_15.setHorizontalAlignment(SwingConstants.CENTER);
		label_15.setForeground(Color.WHITE);
		panel_3.add(label_15);
		
		JPanel panel_4 = new JPanel();
		panel_4.setForeground(Color.WHITE);
		panel_4.setBackground(Color.GRAY);
		panel_4.setBounds(0, 82, 680, 42);
		panel_1.add(panel_4);
		panel_4.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_2 = new JRadioButton("Add Section");
		panel_4.add(radioButton_2);
		
		JLabel label_16 = new JLabel("9:00 To 9:50");
		label_16.setHorizontalAlignment(SwingConstants.CENTER);
		label_16.setForeground(Color.WHITE);
		panel_4.add(label_16);
		
		JLabel label_17 = new JLabel("UTR");
		label_17.setHorizontalAlignment(SwingConstants.CENTER);
		label_17.setForeground(Color.WHITE);
		panel_4.add(label_17);
		
		JLabel lblBuildingRoom_2 = new JLabel("Building 59 Room 101");
		lblBuildingRoom_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_2.setForeground(Color.WHITE);
		panel_4.add(lblBuildingRoom_2);
		
		JLabel label_19 = new JLabel("3");
		label_19.setHorizontalAlignment(SwingConstants.CENTER);
		label_19.setForeground(Color.WHITE);
		panel_4.add(label_19);
		
		JLabel label_20 = new JLabel("83649");
		label_20.setHorizontalAlignment(SwingConstants.CENTER);
		label_20.setForeground(Color.WHITE);
		panel_4.add(label_20);
		
		JLabel label_21 = new JLabel("Lec");
		label_21.setHorizontalAlignment(SwingConstants.CENTER);
		label_21.setForeground(Color.WHITE);
		panel_4.add(label_21);
		
		JLabel label_22 = new JLabel("Omar Alsoma");
		label_22.setHorizontalAlignment(SwingConstants.CENTER);
		label_22.setForeground(Color.WHITE);
		panel_4.add(label_22);
		
		JLabel label_23 = new JLabel("Math201");
		label_23.setHorizontalAlignment(SwingConstants.CENTER);
		label_23.setForeground(Color.WHITE);
		panel_4.add(label_23);
		
		JPanel panel_5 = new JPanel();
		panel_5.setForeground(Color.WHITE);
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(0, 123, 680, 42);
		panel_1.add(panel_5);
		panel_5.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_3 = new JRadioButton("Add Section");
		panel_5.add(radioButton_3);
		
		JLabel lblTo_1 = new JLabel("10:00 To 10:50");
		lblTo_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo_1.setForeground(Color.WHITE);
		panel_5.add(lblTo_1);
		
		JLabel label_25 = new JLabel("UTR");
		label_25.setHorizontalAlignment(SwingConstants.CENTER);
		label_25.setForeground(Color.WHITE);
		panel_5.add(label_25);
		
		JLabel lblBuildingRoom_1 = new JLabel("Building 7 Room 180");
		lblBuildingRoom_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_1.setForeground(Color.WHITE);
		panel_5.add(lblBuildingRoom_1);
		
		JLabel label_27 = new JLabel("3");
		label_27.setHorizontalAlignment(SwingConstants.CENTER);
		label_27.setForeground(Color.WHITE);
		panel_5.add(label_27);
		
		JLabel label_28 = new JLabel("83650");
		label_28.setHorizontalAlignment(SwingConstants.CENTER);
		label_28.setForeground(Color.WHITE);
		panel_5.add(label_28);
		
		JLabel label_29 = new JLabel("Lec");
		label_29.setHorizontalAlignment(SwingConstants.CENTER);
		label_29.setForeground(Color.WHITE);
		panel_5.add(label_29);
		
		JLabel lblRashemMajed = new JLabel("Rashem Majed");
		lblRashemMajed.setHorizontalAlignment(SwingConstants.CENTER);
		lblRashemMajed.setForeground(Color.WHITE);
		panel_5.add(lblRashemMajed);
		
		JLabel label_31 = new JLabel("Math201");
		label_31.setHorizontalAlignment(SwingConstants.CENTER);
		label_31.setForeground(Color.WHITE);
		panel_5.add(label_31);
		
		JPanel panel_6 = new JPanel();
		panel_6.setForeground(Color.WHITE);
		panel_6.setBackground(Color.GRAY);
		panel_6.setBounds(0, 164, 680, 42);
		panel_1.add(panel_6);
		panel_6.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_4 = new JRadioButton("Add Section");
		panel_6.add(radioButton_4);
		
		JLabel lblTo = new JLabel("11:00 To 11:50");
		lblTo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo.setForeground(Color.WHITE);
		panel_6.add(lblTo);
		
		JLabel label_33 = new JLabel("UTR");
		label_33.setHorizontalAlignment(SwingConstants.CENTER);
		label_33.setForeground(Color.WHITE);
		panel_6.add(label_33);
		
		JLabel lblBuildingRoom = new JLabel("Building 24 Room 180");
		lblBuildingRoom.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom.setForeground(Color.WHITE);
		panel_6.add(lblBuildingRoom);
		
		JLabel label_35 = new JLabel("3");
		label_35.setHorizontalAlignment(SwingConstants.CENTER);
		label_35.setForeground(Color.WHITE);
		panel_6.add(label_35);
		
		JLabel label_36 = new JLabel("83651");
		label_36.setHorizontalAlignment(SwingConstants.CENTER);
		label_36.setForeground(Color.WHITE);
		panel_6.add(label_36);
		
		JLabel label_37 = new JLabel("Lec");
		label_37.setHorizontalAlignment(SwingConstants.CENTER);
		label_37.setForeground(Color.WHITE);
		panel_6.add(label_37);
		
		JLabel lblMohammedSaleh = new JLabel("Mohammed Saleh");
		lblMohammedSaleh.setHorizontalAlignment(SwingConstants.CENTER);
		lblMohammedSaleh.setForeground(Color.WHITE);
		panel_6.add(lblMohammedSaleh);
		
		JLabel label_39 = new JLabel("Math201");
		label_39.setHorizontalAlignment(SwingConstants.CENTER);
		label_39.setForeground(Color.WHITE);
		panel_6.add(label_39);
		
		JPanel panel_7 = new JPanel();
		panel_7.setForeground(Color.WHITE);
		panel_7.setBackground(Color.LIGHT_GRAY);
		panel_7.setBounds(0, 205, 680, 42);
		panel_1.add(panel_7);
		panel_7.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_5 = new JRadioButton("Add Section");
		panel_7.add(radioButton_5);
		
		JLabel lblTo_2 = new JLabel("10:30 To 11:45");
		lblTo_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblTo_2.setForeground(Color.WHITE);
		panel_7.add(lblTo_2);
		
		JLabel label_41 = new JLabel("MW");
		label_41.setHorizontalAlignment(SwingConstants.CENTER);
		label_41.setForeground(Color.WHITE);
		panel_7.add(label_41);
		
		JLabel lblBuildingRoom_4 = new JLabel("Building 24 Room 180");
		lblBuildingRoom_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuildingRoom_4.setForeground(Color.WHITE);
		panel_7.add(lblBuildingRoom_4);
		
		JLabel label_43 = new JLabel("3");
		label_43.setHorizontalAlignment(SwingConstants.CENTER);
		label_43.setForeground(Color.WHITE);
		panel_7.add(label_43);
		
		JLabel label_44 = new JLabel("83652");
		label_44.setHorizontalAlignment(SwingConstants.CENTER);
		label_44.setForeground(Color.WHITE);
		panel_7.add(label_44);
		
		JLabel label_45 = new JLabel("Lec");
		label_45.setHorizontalAlignment(SwingConstants.CENTER);
		label_45.setForeground(Color.WHITE);
		panel_7.add(label_45);
		
		JLabel lblAhmedMekki = new JLabel("Ahmed Mekki");
		lblAhmedMekki.setHorizontalAlignment(SwingConstants.CENTER);
		lblAhmedMekki.setForeground(Color.WHITE);
		panel_7.add(lblAhmedMekki);
		
		JLabel label_47 = new JLabel("Math201");
		label_47.setHorizontalAlignment(SwingConstants.CENTER);
		label_47.setForeground(Color.WHITE);
		panel_7.add(label_47);
		
		JPanel panel_8 = new JPanel();
		panel_8.setForeground(Color.WHITE);
		panel_8.setBackground(Color.GRAY);
		panel_8.setBounds(0, 242, 680, 42);
		panel_1.add(panel_8);
		panel_8.setLayout(new GridLayout(0, 9, 0, 0));
		
		JRadioButton radioButton_6 = new JRadioButton("Add Section");
		panel_8.add(radioButton_6);
		
		JLabel label_48 = new JLabel("9:00 To 9:50");
		label_48.setHorizontalAlignment(SwingConstants.CENTER);
		label_48.setForeground(Color.WHITE);
		panel_8.add(label_48);
		
		JLabel label_49 = new JLabel("MW");
		label_49.setHorizontalAlignment(SwingConstants.CENTER);
		label_49.setForeground(Color.WHITE);
		panel_8.add(label_49);
		
		JLabel label_50 = new JLabel("Location");
		label_50.setHorizontalAlignment(SwingConstants.CENTER);
		label_50.setForeground(Color.WHITE);
		panel_8.add(label_50);
		
		JLabel label_51 = new JLabel("3");
		label_51.setHorizontalAlignment(SwingConstants.CENTER);
		label_51.setForeground(Color.WHITE);
		panel_8.add(label_51);
		
		JLabel label_52 = new JLabel("83649");
		label_52.setHorizontalAlignment(SwingConstants.CENTER);
		label_52.setForeground(Color.WHITE);
		panel_8.add(label_52);
		
		JLabel label_53 = new JLabel("Lec");
		label_53.setHorizontalAlignment(SwingConstants.CENTER);
		label_53.setForeground(Color.WHITE);
		panel_8.add(label_53);
		
		JLabel label_54 = new JLabel("Omar Alsoma");
		label_54.setHorizontalAlignment(SwingConstants.CENTER);
		label_54.setForeground(Color.WHITE);
		panel_8.add(label_54);
		
		JLabel label_55 = new JLabel("Math201");
		label_55.setHorizontalAlignment(SwingConstants.CENTER);
		label_55.setForeground(Color.WHITE);
		panel_8.add(label_55);
		
		JButton btnNewButton_1 = new JButton("Submit Changes");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton_1.setBounds(505, 78, 175, 37);
		getContentPane().add(btnNewButton_1);
	}
}
