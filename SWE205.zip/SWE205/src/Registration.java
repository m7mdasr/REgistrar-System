import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Registration {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 680, 406);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		
		JMenu menu = new JMenu("Personal Information ");
		JMenuBar mBar = new JMenuBar();
		mBar.setBounds(500, 0, 230, 25);
		frame.getContentPane().add(mBar);
		mBar.add(menu);
		
		JMenuItem Item1 = new JMenuItem("Change Password");
		Item1.setBounds(497, 24, 183, 19);
		Item1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ChangePassword().main(null);
			}
		});
		menu.add(Item1);
		
		JMenuItem Item2 = new JMenuItem("View Address and Phone");
		Item2.setBounds(479, 45, 199, 19);
		menu.add(Item2);
		
		JMenuItem Item3 = new JMenuItem("Update Address and Phone");
		Item3.setBounds(479, 68, 195, 19);
		menu.add(Item3);
		
		
		
		JLabel lblNewLabel = new JLabel("");
		Image logo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(logo));
		lblNewLabel.setBounds(6, 28, 408, 73);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(133, 113, 436, 234);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton Add = new JButton("Add Course");
		Add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Add a = new Add();
				a.main(null);
			}
		});
		Add.setBounds(50, 28, 147, 71);
		panel.add(Add);
		
		JButton RegSta = new JButton("Registration status");
		RegSta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		RegSta.setBounds(50, 111, 147, 71);
		panel.add(RegSta);
		
		JButton Drop = new JButton("Drop Course");
		Drop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Drop d = new Drop();
				d.main(null);
			}
		});
		Drop.setBounds(247, 28, 147, 71);
		panel.add(Drop);
		
		JButton WS = new JButton("Weekly Schedule");
		WS.setBounds(247, 111, 147, 71);
		panel.add(WS);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Main().main(null);
			}
		});
		btnNewButton.setBounds(0, 0, 117, 29);
		frame.getContentPane().add(btnNewButton);
	}
}
